import { message } from 'antd';


export const addBase64ToForm = async (data, setInput, input,setLoading) => {

}