import {useState} from 'react';

export default function Index(){
    return (
        <div className="">
            <p>ตารางข้อมูลโรคไม่ติดต่อเรื้อรัง</p>
        </div>
    )
}
